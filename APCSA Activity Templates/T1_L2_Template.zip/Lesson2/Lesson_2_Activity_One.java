/*
 * Lesson 2 Coding Activity Question 1
 * 
 * Print the following shape:

    /\
    \/
	
 * (Note you will have to use escape characters to make this work.)
*/

import java.util.Scanner;
import java.lang.Math;

class Lesson_2_Activity_One {
    public static void main(String[] args) {
      
        /* Write your code here 
         * Copy and paste your entire code to Code Runner to complete the activity, 
         * from the first import statement to the last bracket. 
        */


    }
}