/*
 * Lesson 2 Coding Activity Question 3
 * 
 * Write the code to output:

   _
 /   \
|     |
 \ _ /
	
 * It may be easier to get the correct output 
 * if you copy/paste each line from the sample run above.
*/

import java.util.Scanner;
import java.lang.Math;

class Lesson_2_Activity_Three {
    public static void main(String[] args) {
      
        /* Write your code here 
         * Copy and paste your entire code to Code Runner to complete the activity, 
         * from the first import statement to the last bracket. 
        */


    }
}