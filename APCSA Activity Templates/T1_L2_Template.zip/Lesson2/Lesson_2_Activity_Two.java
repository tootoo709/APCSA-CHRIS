/*
 * Lesson 2 Coding Activity Question 2
 * 
 * Using only one "System.out.print" command, 
 * print the following quote. Make sure to include 
 * the quote marks (") in your output.

 "I do not fear computers. I fear the lack of them."
 Isaac Asimov
 
*/

import java.util.Scanner;
import java.lang.Math;

class Lesson_2_Activity_Two {
    public static void main(String[] args) {
      
        /* Write your code here 
         * Copy and paste your entire code to Code Runner to complete the activity, 
         * from the first import statement to the last bracket. 
        */


    }
}