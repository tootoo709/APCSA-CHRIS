/*
 * Lesson 1 Coding Activity Question 1
 * 
 * Write a program to print your name to the center of the output screen. 
 * Use tabs or spaces to center your output, depending on how wide your screen is. 
 * For the code-runner, only one tab or space will be needed for your program to 
 * be counted as acceptable.
 * 
*/

import java.util.Scanner;
import java.lang.Math;

class Lesson_1_Activity_One {
    public static void main(String[] args) {
      
        /* Write your code here 
         * Copy and paste your entire code to Code Runner to complete the activity, 
         * from the first import statement to the last bracket. 
        */


    }
}