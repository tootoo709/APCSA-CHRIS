/*
 * Lesson 1 Coding Activity Question 3
 * 
 * Write a program to output the following:

    ********
    * java *
    ********

 * For an extra challenge: complete this problem using only one line of code.
*/

import java.util.Scanner;
import java.lang.Math;

class Lesson_1_Activity_Three {
    public static void main(String[] args) {
      
        /* Write your code here 
         * Copy and paste your entire code to Code Runner to complete the activity, 
         * from the first import statement to the last bracket. 
        */


    }
}